module.exports = {
  //MongoDB deployment on the cloud
  "URI": "mongodb+srv://Comp229:wrLqAhCgr7NcBpJo@cluster0.v0afqsc.mongodb.net/test"
};
