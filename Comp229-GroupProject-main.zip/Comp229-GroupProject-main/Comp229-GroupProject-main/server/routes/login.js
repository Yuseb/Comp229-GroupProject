// modules required for routing
let express = require('express');
let router = express.Router();
let mongoose = require('mongoose');

// define the game model
let login = require('../views/content');

/* GET home page. wildcard */
router.get('/', (req, res, next) => {
  res.render('content/login', {
    title: 'Login Page',
   });
});

module.exports = router;
